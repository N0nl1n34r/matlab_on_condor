function result_array=extract_from_tr(trPO_array,component)
%% extract components from extended solution
%
% $Id(3.0alpha): extract_from_tr.m 20 2013-06-08 22:30:35Z Jan Sieber $
%
dim=size(trPO_array(1).profile,1)/3;
for i=1:length(trPO_array)
    trPO=trPO_array(i);
    switch component
        case 'kind'
            result='PDorTorusBif';
        case 'solution'
            result=trPO;
            result.profile=result.profile(1:dim,:);
            result.parameter=result.parameter(1:end-2);
        case 'eigenvector'
            result=trPO;
            result.profile=result.profile(dim+1:end,:);
            result.parameter=result.parameter(end-1:end);
        case 'omega'
            result=trPO.parameter(end-1);
        otherwise
            error('TorusBif:unknown','component %s unknown',component);
    end
    result_array(i)=result; %#ok<AGROW>
end
end