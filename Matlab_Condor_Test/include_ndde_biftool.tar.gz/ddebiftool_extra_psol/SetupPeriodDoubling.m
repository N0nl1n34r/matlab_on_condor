function [pdfuncs,pdbranch,suc]=SetupPeriodDoubling(funcs,branch,ind,varargin)
%% initialize continuation of torus or period doubling bifurcations of periodic orbits
% simple wrapper to have a sensible name
%
% $Id(3.0alpha): SetupPeriodDoubling.m 20 2013-06-08 22:30:35Z Jan Sieber $
%
[pdfuncs,pdbranch,suc]=SetupTorusBifurcation(funcs,branch,ind,varargin{:});
end
