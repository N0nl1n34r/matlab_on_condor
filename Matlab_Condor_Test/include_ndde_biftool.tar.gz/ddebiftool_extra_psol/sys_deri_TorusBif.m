function J=sys_deri_TorusBif(xx,par,nx,np,v,hjac,ind_omega,ind_period,dim,funcs,trfuncs)
%% partial derivatives of r.h.s of extended DDE for torus or period doubling bifurcation
%
% $Id(3.0alpha): sys_deri_TorusBif.m 20 2013-06-08 22:30:35Z Jan Sieber $
%

ind_tau=funcs.sys_tau(); % donne la position du ou des retards dans le vecteur des paramètres

if length(nx)==1 && isempty(np) && isempty(v)
    %% first order derivatives of the state
    J=sys_drhs_dx_TorusBif(nx,xx,par(1:ind_omega-1),par(ind_omega),par(ind_period),[0,par(ind_tau)],dim,funcs.sys_deri);
    
elseif isempty(nx) && length(np)==1 && isempty(v)
    
    %% first-order parameter derivatives
    J=sys_drhs_dp_TorusBif(np,xx,par,ind_omega,ind_period,ind_tau,dim,funcs.sys_deri);
    
else
    
    %% shouldn't be needed
    disp('WARNING : use a part of function which should not be needed. NOT checked for NDDES.')
    J=df_deriv(trfuncs,xx,par,nx,np,v,hjac);
end

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function J=sys_drhs_dx_TorusBif(ind,x,p,omega,period,tau,dim,sys_deri)

% ind = variable wrt to which we derive (if we go in this function, we
% derive wrt one of the variable).

if exist('sys_ndde')
    ndde = 1;

else
    ndde = 0;
end

%% derivative of rhs of extended DDE for torus bif wrt to x(:,i)
nvec=size(x,3);     % number of points per period 
x0=x(1:dim,:,:);
u=x(dim+1:2*dim,:,:); % NB: u and v are same dim as the system itself as we linearise each equation of f (eq 3 in doc continuation bif NS for neutral)
v=x(2*dim+1:end,:,:);

% derivees, avec length(nx)=1, donc derivee premiere
Jxx=sys_deri(x0,p,ind,[],[]); %derivative of x rhs with respect to x
Jxu=zeros(dim,dim,nvec);  % derivative of x rhs wrt u = 0
Jxv=zeros(dim,dim,nvec);  % derivative of x rhs wrt v = 0

Jux=zeros(dim,dim,nvec);  % derivative of u rhs wrt x
Juu=zeros(dim,dim,nvec);  % derivative of u rhs wrt u
Juv=zeros(dim,dim,nvec);  % derivative of u rhs wrt v

Jvx=zeros(dim,dim,nvec);  % derivative of v rhs wrt x
Jvu=zeros(dim,dim,nvec);  % derivative of v rhs wrt u
Jvv=zeros(dim,dim,nvec);  % derivative of v rhs wrt v

PiOmT=pi*omega/period;

pid=PiOmT*eye(dim); 
pid=pid(:,:,ones(1,nvec)); % duplicate pid matrix by the number of discrete points in a period
%keyboard

if ind==0        % ind=0 means that we derive wrt to non delayed variable 
    Juv=Juv+pid;
    Jvu=Jvu-pid;
end

%%CASE OF NEUTRAL SYSTEMS
if ndde
    d = size(x0,2)-0.5*(size(x0,2)-1); %number of delays (with the delay 0)
    
    for i=1:d %for each non neutral term
        c=cos(pi*omega/period*tau(i));
        s=sin(pi*omega/period*tau(i));
        
        Jux=Jux+sys_deri(x0,p,[i-1,ind],[], c*u(:,i,:)+s*v(:,i,:));
        Jvx=Jvx+sys_deri(x0,p,[i-1,ind],[],-s*u(:,i,:)+c*v(:,i,:));
        %ajout NDDE :
        if i~=1
        Jux=Jux+sys_deri(x0,p,[i-1+d-1,ind],[], c*u(:,i+d-1,:)+s*v(:,i+d-1,:)-PiOmT*c*v(:,i,:)+PiOmT*s*u(:,i,:)); %modified on 29/11/2017
        Jvx=Jvx+sys_deri(x0,p,[i-1+d-1,ind],[],-s*u(:,i+d-1,:)+c*v(:,i+d-1,:)+PiOmT*c*u(:,i,:)+PiOmT*s*v(:,i,:)); %modified on 29/11/2017
        end
        
        %NB comme on pointe vers sys deri, les derivee par rapport a eu et
        %v ne sont pas prises en compte ici.
        %NB2: Quand on est dans cette function, on ne derive auqe par
        %rapport a un type de variable (non retardee ou retardee de tau1 ou retardee de tau2) ! 
        %Pour x=les derivee par rapport a x on derive quand meme par
        %rapport a chaque variable retardeee parce que ces derivees sont DANS le rhs de
        %u.
        
        % HEAVILY CHANGED ON 01/12/2017
        if i-1==ind % ca n'arrive qu'une fois dans la boucle, et la condition assure que c et s sont definis avec le bon retard.
            difp=sys_deri(x0,p,ind,[],[]);
            dif_neutral = sys_deri(x0,p,ind+d-1,[],[]); %added on 29/11/2017
            
            if ind==0
                Juu = Juu+difp;
                Jvv = Jvv+difp;
                %Juv  already defined for ind=0
                %Jvu already defined for ind=0
            elseif ind<d
                Juu = Juu+difp*c+dif_neutral*s*omega*PiOmT;
                Juv = Juv+difp*s-dif_neutral*PiOmT*c;
                Jvu = Jvu-difp*s+PiOmT*c*dif_neutral;
                Jvv = Jvv + difp*c + dif_neutral*PiOmT*s;
            else %derivative wrt to delayed derivative terms
                Juu = Juu+dif_neutral*c;
                Juv = Juv+dif_neutral*s;
                Jvu = Jvu-dif_neutral*s;
                Jvv = Jvv+dif_neutral*c;
            end
            
        end
        
        
    end
    J=cat(1,cat(2,Jxx,Jxu,Jxv),cat(2,Jux,Juu,Juv),cat(2,Jvx,Jvu,Jvv));
else    
    for i=1:size(x0,2) %for each delay, including zero delay
        c=cos(pi*omega/period*tau(i));
        s=sin(pi*omega/period*tau(i));
        
        %calcul des derivees de rhs de u et v par rapport aux variables d'etat
        Jux=Jux+sys_deri(x0,p,[i-1,ind],[], c*u(:,i,:)+s*v(:,i,:)); 
        Jvx=Jvx+sys_deri(x0,p,[i-1,ind],[],-s*u(:,i,:)+c*v(:,i,:));
        
        if i-1==ind
            difp=sys_deri(x0,p,ind,[],[]);
            Juu=Juu+difp*c;
            Juv=Juv+difp*s;
            Jvu=Jvu-difp*s;
            Jvv=Jvv+difp*c;
        end
    end
    J=cat(1,cat(2,Jxx,Jxu,Jxv),cat(2,Jux,Juu,Juv),cat(2,Jvx,Jvu,Jvv));
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function J=sys_drhs_dp_TorusBif(ind,x,par,ind_omega,ind_period,ind_tau,dim,sys_deri)
    
if exist('sys_ndde')
    ndde = 1;
else
    ndde = 0;
end
    
%% derivative of rhs of extended DDE for torus bif wrt to parameters
nvec=size(x,3);
x0=x(1:dim,:,:);
u=x(dim+1:2*dim,:,:);
v=x(2*dim+1:end,:,:);
omega=par(ind_omega);
period=par(ind_period);
tau=[0,par(ind_tau)];
p=par(1:ind_omega-1);
PiOmT=pi*omega/period;

if ind<ind_omega %i.e. we derive wrt to a physical parameter of the non extended system
    
    %% derivative wrt system parameter %% FAUT-IL AJOUTER DES TERMES ICI ????
    Jx=sys_deri(x0,p,[],ind,[]);
    Ju=zeros(dim,1,nvec);
    Jv=zeros(dim,1,nvec);
    
    if ndde
        d = size(x0,2)-0.5*(size(x0,2)-1);
        
        for i=1:d
            c=cos(PiOmT*tau(i));
            s=sin(PiOmT*tau(i));
            difxp=sys_deri(x0,p,i-1,ind,[]); %derivative of non extended system wrt to STATE VAR AND PARAMETER, evaluated at x0,p
            Ju=Ju+VAopX(difxp, c*u(:,i,:)+s*v(:,i,:),'*'); %only multiplication as the c+s term does not depend on system parameters
            Jv=Jv+VAopX(difxp,-s*u(:,i,:)+c*v(:,i,:),'*');
            
                if i>1 %ie a delayed term with non zero delay 
                    difxp_neutral=sys_deri(x0,p,i-1+d-1,ind,[]); %derivative of non extended system rhs with respect to derivative delayed state variable AND parameter
                    Ju=Ju+VAopX(difxp_neutral, c*u(:,i+d-1,:)+s*v(:,i+d-1,:)+PiOmT*s*u(:,i,:)-PiOmT*c*v(:,i,:),'*'); 
                    Jv=Jv+VAopX(difxp_neutral,-s*u(:,i+d-1,:)+c*v(:,i+d-1,:)-PiOmT*c*u(:,i,:)+PiOmT*s*v(:,i,:),'*');
                end
                    
                    if i>1 && ind==ind_tau(i-1)
                        
                        difx=sys_deri(x0,p,i-1,[],[]);
                        Ju=Ju+VAopX(difx*PiOmT,-s*u(:,i,:)+c*v(:,i,:),'*');
                        Jv=Jv+VAopX(difx*PiOmT,-c*u(:,i,:)-s*v(:,i,:),'*');
                        
                        difx_neutral = sys_deri(x0,p,i-1+d-1,[],[]); 
                        Ju = Ju+VAopX(difx_neutral*PiOmT,-s*u(:,i+d-1,:)+c*v(:,i+d-1,:)+PiOmT*s*v(:,i,:)+PiOmT*c*u(:,i,:),'*');
                        Jv = Jv+VAopX(difx_neutral*PiOmT,-s*v(:,i+d-1,:)-c*u(:,i+d-1,:)-PiOmT*s*u(:,i,:)+PiOmT*c*v(:,i,:),'*');

                    end

        end
        
    else    %non neutral case
        
        for i=1:size(x0,2)
            c=cos(PiOmT*tau(i));
            s=sin(PiOmT*tau(i));
            difxp=sys_deri(x0,p,i-1,ind,[]);
            Ju=Ju+VAopX(difxp, c*u(:,i,:)+s*v(:,i,:),'*');
            Jv=Jv+VAopX(difxp,-s*u(:,i,:)+c*v(:,i,:),'*');
                if i>1 && ind==ind_tau(i-1)
                    difx=sys_deri(x0,p,i-1,[],[]);
                    Ju=Ju+VAopX(difx*PiOmT,-s*u(:,i,:)+c*v(:,i,:),'*');
                    Jv=Jv+VAopX(difx*PiOmT,-c*u(:,i,:)-s*v(:,i,:),'*');
                end
        end
        
    end
    J=cat(1,Jx,Ju,Jv);
elseif ind==ind_omega || ind==ind_period % special case of derivation with respect to parameters of the extended system
    
    Jx=zeros(dim,1,nvec); %Jx is zero as the rhs of the non extended system does not explicitely depend on T or omega
    Ju=pi*v(:,1,:); %same calculation at first for T or omega, see later.
    Jv=-pi*u(:,1,:);
    
    if ndde
        d = size(x0,2)-0.5*(size(x0,2)-1);
        for i=1:d
            c=cos(PiOmT*tau(i));
            s=sin(PiOmT*tau(i));
            
            difx=sys_deri(x0,p,i-1,[],[]); % derivative wrt to state variable only; no need for crossed terms ad non extended rhs does not have omega or T in it 
            
            Ju=Ju+VAopX(difx*pi*tau(i),-s*u(:,i,:)+c*v(:,i,:),'*');
            Jv=Jv+VAopX(difx*pi*tau(i),-c*u(:,i,:)-s*v(:,i,:),'*');
            
            if i>1 %ndde terms modified on 29/11/2017
                difx_neutral=sys_deri(x0,p,i-1+d-1,[],[]); %derivative wrt to neutral term
                Ju = Ju+VAopX(difx_neutral*pi*tau(i),-s*u(:,i+d-1,:)+c*v(:,i+d-1,:),'*');
                Jv = Jv+VAopX(difx_neutral*pi*tau(i),-c*u(:,i+d-1,:)-s*v(:,i+d-1,:),'*');
                
                Ju = Ju+VAopX(difx_neutral*pi,(s+omega*pi*tau(i)/period*c)*u(:,i,:)+(-c+omega*pi*tau(i)/period*s)*v(:,i,:),'*'); %added on 01/12               
                Jv = Jv+VAopX(difx_neutral*pi,(c-omega*pi*tau(i)/period*s)*u(:,i,:)+(s+omega*pi*tau(i)/period*c)*v(:,i,:),'*');%added on 01/12
            end                
        end
    else %non neutral case
        for i=1:size(x0,2)
            c=cos(PiOmT*tau(i));
            s=sin(PiOmT*tau(i));
            difx=sys_deri(x0,p,i-1,[],[]);
           
            Ju=Ju+VAopX(difx*pi*tau(i),-s*u(:,i,:)+c*v(:,i,:),'*');
            Jv=Jv+VAopX(difx*pi*tau(i),-c*u(:,i,:)-s*v(:,i,:),'*');
  
        end
    end %end neutral if
    J=cat(1,Jx,Ju,Jv);
    if ind==ind_omega
        J=J/period;
    else
        J=-J*omega/period^2;
    end
end
end
