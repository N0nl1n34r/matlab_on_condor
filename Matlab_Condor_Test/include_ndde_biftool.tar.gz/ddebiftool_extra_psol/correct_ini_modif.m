function [branch,suc]=correct_ini(funcs,branch,pini,dir,step,correc)
%% set and correct first (two) initial points along branch
%
% $Id(3.0alpha): correct_ini.m 20 2013-06-08 22:30:35Z Jan Sieber $
%
suc=true;
if correc
    %% correct initial guess
    rcond=funcs.sys_cond(pini);
    ncond=length(rcond);
    if strcmp(pini.kind,'hopf')||strcmp(pini.kind,'fold')
        %% fix for Hopf because add. conditions are not implemented as sys_cond
        ncond=ncond+1;
    end
    mth=branch.method.point;
%     [pfirst,suc]=p_correc(funcs,pini,branch.parameter.free(end-ncond+1:end),[],mth,1,pini);
    [pfirst,suc]=p_correc(funcs,pini,branch.parameter.free(end-ncond+1:end),[],mth);
    
    if ~suc
        recorrec = input('Continuer à corriger ce point ? (o/n)','s');
        while strcmp(recorrec,'o')==1
           [pfirst,suc]=p_correc(funcs,pfirst,branch.parameter.free(end-ncond+1:end),[],mth); 
           if suc
               recorrec = 'n';
           else
               recorrec = input('Continuer à corriger ce point ? (o/n)','s');
           end
        end
           if ~suc
             pfirst=pini;
             warning('correct_ini:fail','Correction failed');  
           end
%         else
%             pfirst=pini;
%             warning('correct_ini:fail','Correction failed');
%         end
    end
else
    pfirst=pini;
end
branch=rmfield(branch,'point');
branch.point(1)=pfirst;
if ~suc
    return
end
%% append 2nd point if desired
if ~isempty(dir)
    p2=branch.point(1);
    p2.parameter(dir)=p2.parameter(dir)+step;
    if correc
        disp('correction of the 2nd point of the branch')
        corpar=setdiff(branch.parameter.free,dir);
        [p2c,suc]=p_correc(funcs,p2,corpar,[],mth);%,1,p2);
        if suc
            branch.point(2)=p2c;
        else
            warning('correct_ini:fail','Correction failed');
        end
    else
        p2c=p2;
    end
    branch.point(2)=p2c;
end
end
