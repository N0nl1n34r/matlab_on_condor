function y=sys_rhs_TorusBif(x,p,omega,period,tau,sys_rhs,dim,sys_deri)
%% r.h.s. of extended DDE for torus and period doubling bifurcation
% argument sys_deri can be either numeric (say, 1e-3, then a
% finite-difference approximation is used for the linearized system), or a
% function providing the partial derivatives of the DDE's sys_rhs
%
% $Id(3.0alpha): sys_rhs_TorusBif.m 20 2013-06-08 22:30:35Z Jan Sieber $
% SIGNIFICANTLY MODIFIED BY S.T. ON 01/12/2017

if exist('sys_ndde')
    ndde = 1;
else
    ndde = 0;
end


x0=x(1:dim,:,:);

u=x(dim+1:2*dim,:,:);
v=x(2*dim+1:end,:,:);

y0=sys_rhs(x0,p);

yu=pi*omega/period*v(:,1,:);
yv=-pi*omega/period*u(:,1,:);

if isnumeric(sys_deri) 
    %% no user-provided derivative (sys_deri is size of deviation)
    df=@(x0,dev,ind) app_dir_deriv(@(x)sys_rhs(x,p),x0,dev,ind,sys_deri);
else
    %% sys_deri is user-provided function
    df=@(x0,dev,ind) VAopX(sys_deri(x0,p,ind,[],[]),dev,'*');
end

%keyboard

if ndde
    
    d = size(x0,2)-0.5*(size(x0,2)-1); %number of delays including the zero delay
    
    for i=1:d %indice du retard
        %% add partial derivatives of all delayed terms (incl delay zero)
        c=cos(pi*omega/period*tau(i));  %1 for zero delay
        s=sin(pi*omega./period*tau(i)); %0 for zero delay
        
        wpiT = omega*pi./period;
        
        yu=yu+df(x0, c*u(:,i,:)+s*v(:,i,:),i-1); % !!!! i-1 because index is defined from 0
        yv=yv+df(x0,-s*u(:,i,:)+c*v(:,i,:),i-1);
        
        if ndde
         if i~=1 %(le cas i=1 correspond au cas non retarde)
             yu=yu+df(x0, c*u(:,i+d-1,:) +s*v(:,i+d-1,:)+wpiT*s*u(:,i,:) - wpiT*c*v(:,i,:),i+d-2);
             yv=yv+df(x0,-s*u(:,i+d-1,:)+c*v(:,i+d-1,:)+wpiT*s*v(:,i,:)+wpiT*c*u(:,i,:),i+d-2);
         end 
        end
    end
    
else
    
     for i=1:size(x0,2)  %pour chaque retard
    %% add partial derivatives of all delayed terms (incl delay zero)
        c=cos(pi*omega/period*tau(i));
        s=sin(pi*omega./period*tau(i));
        yu=yu+df(x0, c*u(:,i,:)+s*v(:,i,:),i-1);
        yv=yv+df(x0,-s*u(:,i,:)+c*v(:,i,:),i-1);
    end
end
    
y=cat(1,y0,yu,yv);
% keyboard
end
