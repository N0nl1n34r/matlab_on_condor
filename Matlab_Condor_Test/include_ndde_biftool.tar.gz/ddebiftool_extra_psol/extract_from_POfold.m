function result_array=extract_from_POfold(pfold_array,component,npar)
%% extract components from pfold
%
% $Id(3.0alpha): extract_from_POfold.m 20 2013-06-08 22:30:35Z Jan Sieber $
%
dim=size(pfold_array(1).profile,1)/2;
for i=1:length(pfold_array)
    pfold=pfold_array(i);
    switch component
        case 'kind'
            result='POfold';
        case 'solution'
            result=pfold;
            result.profile=result.profile(1:dim,:);
            result.parameter=result.parameter(1:npar);
        case 'nullvector'
            result=pfold;
            result.profile=result.profile(dim+1:end,:);
            result.parameter=result.parameter(npar+1);
        case 'delays'
            result.values=pfold.parameter(npar+3:end);
    end
    result_array(i)=result; %#ok<AGROW>
end
end
