function branch=replace_branch_pars(branch,contpar,pass_on)
%% pass on optional arguments
%
% $Id(3.0alpha): replace_branch_pars.m 20 2013-06-08 22:30:35Z Jan Sieber $
%
branch.method.continuation=dde_set_options(branch.method.continuation,pass_on,'pass_on');
branch.method.point=dde_set_options(branch.method.point,pass_on,'pass_on');
if isempty(contpar)
    % if no continuation parameters are given use free parameters of branch
    branch.parameter.free=branch.parameter.free;
elseif length(contpar)==1;
    % if single continuation parameter is given prepend to free parameters of branch
    branch.parameter.free=[contpar,branch.parameter.free];
else
    branch.parameter.free=contpar(:)';
end
branch.parameter=dde_set_options(branch.parameter,pass_on,'pass_on');
end
