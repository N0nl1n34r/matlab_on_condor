function [stab,eigv,A] = p_stabil_ndde_multi(funcs,st1,N)
% function [stab,eigv] = p_stabil_ndde_multi(st1,N)
%
% Use the method described in Breda, Maset, and Vermiglio 2006
% (Pseudospectral approximation of eigenvalues of derivative operators with
% non-local boundary conditions)
%
% st1 is a steady state solution
% N is the (optional) size of the discretisation to use
%
% Uses a modified version of A Matlab Differentiation Matrix Suite by JAC
% Weideman and SC Reddy
% <http://dip.sun.ac.za/~weideman/research/differ.html>
%% the following cell has been added on 28/11/2013 
sys_tau = funcs.sys_tau;
sys_deri = funcs.sys_deri;
%%

if exist('N', 'var') ~= 1
    N = 100;
end;


% dimension of system
n = size(st1.x,1);

% get the delays and the maximum delay
tau = st1.parameter(sys_tau());
nTau = length(tau);
maxTau = max(tau)

% get the (1st) differentiation matrix and the Chebyshev nodes
[~, D] = chebdif(N,1);

% chebdif returns the Chebyshev differentiation matrix on [1..-1] so
% rescale to [-1..0]
D = -D*2/maxTau;

% Fudge it to the correct dimension
A = kron(D,eye(n));
D = kron(D,eye(n));
% keyboard

% Construct the solution vector (remember, neutral derivatives are zero at
% an equilibrium)
xx = st1.x*[1 ones(1, nTau) zeros(1, nTau)];

% Overwrite the bottom row of the matrix A
A(end-n+1:end, :) = 0;

% Add the necessary derivatives
L0 = sys_deri(xx,st1.parameter,0,[],[]);
A(end-n+1:end,end-n+1:end) = L0;

% Add the delayed derivatives
for i = 1:nTau
    Li = sys_deri(xx,st1.parameter,i,[],[]); % Get the delay derivatives
    Ni = sys_deri(xx,st1.parameter,i+nTau,[],[]); % Get the neutral derivatives
    [~, I] = chebintD(zeros(1,N), -2*tau(i)/maxTau + 1); % Rescale tau to the interval [-1..1]
%     I=I(end:-1:1);
    I = kron(I, eye(n)); % Expand to the system dimension
%     keyboard
    A(end-n+1:end, :) = A(end-n+1:end, :) + Li*I + Ni*I*D'; 
%     for jj=1:n
%         for kk=1:N
% %             keyboard
%             A(end-n+jj,(kk-1)*n+1:kk*n) = A(end-n+jj,(kk-1)*n+1:kk*n) + Ior(kk)*D(kk,1)*Ni(jj,:); 
% %             A(end-n+jj,:)
% %             pause
%         end
%     end
end

%% OK APRES CA

% Calculate the eigenvalues
if nargout >= 2
    [eigv,l] = eig(A);
    l = diag(l);
    [~,idx] = sort(real(l),1,'descend');
    eigv = eigv(:,idx);
else
    l = eig(A);
    [~,idx] = sort(real(l),1,'descend');
end;
size(A)
stab.l0 = [];
stab.l1 = l(idx);
stab.n1 = [];
