function biftool

disp('DDE-BIFTOOL v. 2.00, released 16/12/2001');
disp('Koen.Engelborghs@cs.kuleuven.ac.be');
disp('Tatyana.Luzyanina@cs.kuleuven.ac.be (state-dependent delays)');
disp('Giovanni.Samaey@cs.kuleuven.ac.be (connecting orbits)');
disp('Usage of DDE-BIFTOOL is restricted by the warranty notice');
disp('given in its manual.');

return;
