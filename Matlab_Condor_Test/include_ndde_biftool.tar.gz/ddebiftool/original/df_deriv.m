function J=df_deriv(funcs,xx,par,nx,np,v,hjac)

% function J=df_deriv(funcs,xx,par,nx,np,v [,hjac])
% INPUT:
%   funcs  problem functions
%	xx state variable and delayed state variables columnwise
%	par list of parameter values
%	nx empty or list of requested state-derivatives (numbers of delay or zero) 
%	np empty or list of requested parameter-derivatives 
%	v matrix to multiply result with
%   hjac (optional) length of deviation (absolute and relative)
% OUTPUT:
%	J result of derivatives on righthandside multiplied with v
% COMMENT:
%	the numerical derivatives are evaluated using forward differences

% (c) DDE-BIFTOOL v. 1.00, 11/03/2000

% first order derivative discretisation parameters:

sys_rhs=funcs.sys_rhs;
if nargin==6
    hjac=1e-6;
end
abs_eps_x1=hjac;
abs_eps_x2=hjac;
abs_eps_p1=hjac;
abs_eps_p2=hjac;
rel_eps_x1=hjac;
rel_eps_x2=hjac;
rel_eps_p1=hjac;
rel_eps_p2=hjac;

n=size(xx,1);

J=[];

% first order derivatives of the state:
if length(nx)==1 && isempty(np) && isempty(v),
  f=sys_rhs(xx,par);
  J=zeros(length(f),n);
  for j=1:n
    xx_eps=xx;
    eps=abs_eps_x1+rel_eps_x1*abs(xx(j,nx+1));
    xx_eps(j,nx+1)=xx(j,nx+1)+eps;
    J(:,j)=(sys_rhs(xx_eps,par)-f)/eps;
  end;
% first order parameter derivatives:
elseif isempty(nx) && length(np)==1 && isempty(v),
  f=sys_rhs(xx,par);
  par_eps=par;
  eps=abs_eps_p1+rel_eps_p1*abs(par(np));
  par_eps(np)=par(np)+eps;
  J=(sys_rhs(xx,par_eps)-f)/eps;
% second order state derivatives:
elseif length(nx)==2 && isempty(np) && ~isempty(v),
  for j=1:n
    J(:,j)=df_deriv(funcs,xx,par,nx(1),[],[],hjac)*v;
    xx_eps=xx;
    eps=abs_eps_x2+rel_eps_x2*abs(xx(j,nx(2)+1));
    xx_eps(j,nx(2)+1)=xx_eps(j,nx(2)+1)+eps;
    J(:,j)=(df_deriv(funcs,xx_eps,par,nx(1),[],[],hjac)*v-J(:,j))/eps;
  end;
% mixed state parameter derivatives:
elseif length(nx)==1 && length(np)==1 && isempty(v),
  J=df_deriv(funcs,xx,par,nx(1),[],[],hjac);
  par_eps=par;
  eps=abs_eps_p2+rel_eps_p2*abs(par(np));
  par_eps(np)=par(np)+eps;
  J=(df_deriv(funcs,xx,par_eps,nx(1),[],[],hjac)-J)/eps;
end;

if isempty(J)
  [nx np size(v)] %#ok<NOPRT>
  error('SYS_DERI: requested derivative does not exist!');
end;

return;

