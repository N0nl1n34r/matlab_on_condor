function [J,res] = psol_jac(col,T,profile,mesh,degree,par,free_par,phase)

% function [J,res]=psol_jac(c,T,profile,t,deg,par,free_par,phase)
% INPUT:
%	c collocation parameters in [0,1]^deg
%	T period 
%	profile profile in R^(n x deg*l+1)
%	t representation points in [0,1]^(deg*l+1)
%	deg degree piecewise polynomial
%	par current parameter values in R^p
%	free_par free parameters numbers in N^d 
%	phase use phase condition or not (s = 1 or 0)
% OUTPUT: 
%	J jacobian in R^(n*deg*l+n+s x n*deg*l+1+n+d)
%	res residual in R^(n*deg*l+n+s)
%
% Heavily modified by David A.W. Barton (August 2005 to January 2006)
% (c) DDE-BIFTOOL v. 2.00, 30/11/2001


% get the system dimension from the dimensions of profile
sysn = size(profile,1);
% degree of interpolating polynomials
sysm = degree;
% number of mesh points (mesh points + representation points==length(mesh))
sysl = (length(mesh) - 1)/sysm;


f1=[];
f2=[];
f3=[];
f4=[];


x_tot=zeros(4,sysl*sysm);
xtau_tot=zeros(4,sysl*sysm);
dxtau_tot=zeros(4,sysl*sysm);

% check that the mesh size is correct
if ((sysl ~= floor(sysl)) || (length(mesh) ~= size(profile,2)))
    error('PSOL_JAC: Mesh size is wrong!');
end;

% check collocation points
if ((length(col) ~= 0) && (length(col) ~= sysm))
    error('PSOL_JAC: Wrong number of collocation points');
end;

% get number of delays to consider
if (nargin('sys_tau') == 0)  
    % constant delays
    n_tau = sys_tau;    % location of delays in parameter list
    tau = par(n_tau);   % values of the delays
    tT = tau/T;         % normalised delay values
    nd = length(n_tau); % number of delays
else
    error('PSOL_JAC: State-dependent delay is not yet supported');
end;

% do some extra initialisation if we are working on an NDDE
% get the mass matrix M where M*x'(t) = f(x(t),x(t-tau),x'(t-tau))
if exist('sys_ndde')
    massmatrix = sys_ndde();
    if ((size(massmatrix,1) ~= sysn) || (size(massmatrix,2) ~= sysn))
        if (size(massmatrix,1)*size(massmatrix,2)) == 1
            massmatrix = eye(sysn);
        else
            error('PSOL_JAC: Incorrectly sized mass matrix given by sys_ndde');
        end;
    end;
    ndde = 1;
else
    massmatrix = eye(sysn);
    ndde = 0;
end;

% create some collocation points (Gaussian) if we weren't given any
if (length(col) == 0) %% On est la plupart du temps dans ce cas là, à moins que l'utilisateur ait fourni des paramètres de collocation !!!
    col = poly_gau(sysm);
    gauss_c = col;
    non_gauss = 0;
else
    gauss_c = poly_gau(sysm);
    non_gauss = 1;
end;

% phase condition initialisation
if phase
  gauss_abs=ones(1,sysm);
  g=poly_gau(sysm-1);
  for k=1:sysm
    for j=1:sysm-1
      gauss_abs(k)=gauss_abs(k)/(gauss_c(k)-g(j));
    end;
    for j=1:sysm
      if j~=k
        gauss_abs(k)=gauss_abs(k)/(gauss_c(k)-gauss_c(j));
      end;
    end;
  end;
  gauss_abs=gauss_abs/sum(gauss_abs);
end;

% create our Lagrange polynomials at the collocation points
P0 = zeros(sysm+1,sysm+1);
dP0 = zeros(sysm+1,sysm+1);
ddP0 = zeros(sysm+1,sysm+1);
for i = 1:sysm
    P0(i,:) = poly_elg(sysm,col(i));     % Lagrange polynomial
    dP0(i,:) = poly_del(sysm,col(i));    % and its 1st derivative
    ddP0(i,:) = poly_ddel(sysm,col(i));  % and its 2nd derivative
end;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% OK jusque là
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% some optimisations
sysnm = sysn*sysm;
sysnml = sysnm*sysl;

% create the jacobian matrix and residual
J = zeros(sysnml + sysn + phase,sysnml + sysn + 1 + length(free_par));
% J = (collocation eqns + BCs + phase cond)x(interp pts + period + pars)
res = zeros(sysnml + sysn + phase,1);

% iterate through the mesh points
for l = 1:sysl

    % the starting index in the profile
    idx = sysm*(l - 1) + 1;
    % the starting (horizontal) index in the jacobian
    idxjac = (idx - 1)*sysn + 1;
    % find the start time
    ts = mesh(idx);
    % determine the width of the mesh interval (pas temporel entre deux
    % interavls successifs)
    h = mesh(idx + sysm) - ts;
    
    % iterate through the collocation points : dans l'intervalle courant,
    % on considère chaque point de collocation.
    for m = 1:sysm
        
        % the starting index in the profile
        idxm = idx + m - 1;
        % the starting index in the jacobian
        idxjacm = idxjac + (m - 1)*sysn;
        % the range in res we want to modify (only a range if multidim)
        idxrange = [idxjacm:idxjacm + sysn - 1];   %pour le point de collocation courant, on prend toutes les colonnes du jacobien qui correspondent à ce point, ie pour toutes les variables)
        % get the Lagrange polynomials on this interval (en fait,
        % sous-intervalle)
        P = P0(m,:);
        dP = dP0(m,:)/h;       %comme on dérive par rapport au temps, le pas temporel du maillage intervient
        ddP = ddP0(m,:)/(h^2);
        % find the time of the current collocation point
        coltime = ts + col(m)*h; 
        % determine x(t) at the collocation point (of the current interval)
        x = profile(:,idx:(idx + sysm))*P';
        dx = profile(:,idx:(idx + sysm))*dP';
%%       
        % phase_condition
        if phase && ~non_gauss   %si on dérive l'equation de phase ?
            fup = gauss_abs(m)*h*dx';
            i_l_i= (l - 1)*sysnm; %dans le jacobien, point de départ (indice de la colonne) correspondant au premier point de l'intervalle courant
            for q=0:sysm %pour chaque point de collocation de cette intervalle ...        
                qq=i_l_i+q*sysn; % ... on considère les n variables
                J(sysnml + sysn + 1,qq+1:qq+sysn) = J(sysnml + sysn + 1,qq+1:qq+sysn)+P(q+1)*fup; %on remplit la dernière ligne du jacobien (correspondant à l'équation de phase)
            end;
        end;
    
        % determine x(t-tau) for all delays
%% CE FOR EST OK
        for numtau = 1:nd
        
            % where does t-tau look back to
            coltime_tau_i = mod(coltime - tT(numtau),1);
            % do a linear search for the corresponding mesh interval
            idxtau_i = length(mesh) - sysm;
            while (coltime_tau_i < mesh(idxtau_i))
                idxtau_i = idxtau_i - sysm;
            end;
            idxtau(numtau) = idxtau_i;
            % the width of the mesh interval
            h_tau = mesh(idxtau_i + sysm) - mesh(idxtau_i);
            % transform coltime_tau_i onto [0,1]
            coltime_trans = (coltime_tau_i - mesh(idxtau_i))/h_tau;
            % find the Lagrange polynomials
            Ptau(numtau,:) = poly_elg(sysm,coltime_trans);
            dPtau(numtau,:) = poly_del(sysm,coltime_trans)/h_tau;
            ddPtau(numtau,:) = poly_ddel(sysm,coltime_trans)/(h_tau^2);
            % compute x(t-tau)
            xtau(:,numtau) = profile(:,idxtau_i:(idxtau_i+sysm))*Ptau(numtau,:)';
            dxtau(:,numtau) = profile(:,idxtau_i:(idxtau_i+sysm))*dPtau(numtau,:)';
            ddxtau(:,numtau) = profile(:,idxtau_i:(idxtau_i+sysm))*ddPtau(numtau,:)';
            
        % END: for numtau = 1:nd
        end;
        %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% OK jusque là
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        % NDDE: add derivatives for neutral equations (remember to rescale
        %   dxtau from [0:1] to [0:T])
        xx = [x xtau dxtau/T]; 
        x_tot(:,idxm)=x;
        xtau_tot(:,idxm)=xtau;
        dxtau_tot(:,idxm)=dxtau/T;
%         figure(1); hold on; plot(idxm,x(1),'x'); plot(idxm,xtau(1),'xr'); plot(idxm,x(2),'xk'); plot(idxm,xtau(2),'xm'); plot(idxm,x(3),'o'); plot(idxm,xtau(3),'xc'); plot(idxm,x(4),'ok'); plot(idxm,xtau(4),'xy')
%         figure(2); hold on; plot(idxm,dx(1),'x'); plot(idxm,dxtau(1),'xr'); plot(idxm,dx(2),'xk'); plot(idxm,dxtau(2),'xm'); plot(idxm,dx(3),'o'); plot(idxm,dxtau(3),'xc'); plot(idxm,dx(4),'ok'); plot(idxm,dxtau(4),'xy')
%         figure(3); hold on; plot(idxm,ddxtau(1),'xr'); plot(idxm,ddxtau(2),'xm'); plot(idxm,ddxtau(3),'xc'); plot(idxm,ddxtau(4),'xy')
        % compute the RHS for the current collocation point
        f = sys_rhs(xx,par);
        
       
        f1(end+1)=f(1,1);
        f2(end+1)=f(2,1);
        f3(end+1)=f(3,1);
        f4(end+1)=f(4,1);
        % compute the residual for the collocation equations
        %ligne suivante OK
        res(idxrange) = res(idxrange) + (massmatrix*dx - T*f);
       
        %% OK add the free parameter derivatives to the jacobian 
        %% OK pour les resultats
        for i = 1:length(free_par)
            df = sys_deri(xx,par,[],free_par(i),[]);
            J(idxrange,sysnml + sysn + 1 + i) = -T*df;
        end;

        %% OK ... si tout fonctionne avec la matrice de masse
        
        % add (sum P'(c)*Delta u) to the jacobian
        for k = 0:sysm
            kk = idxjac + k*sysn;   
            J(idxrange,kk:(kk+sysn-1)) = J(idxrange,kk:(kk+sysn-1)) + massmatrix*dP(k+1);
        end;
        %% OK
        % add -f*Delta T to the jacobian
        J(idxrange,sysnml + sysn + 1) = J(idxrange,sysnml + sysn + 1) - f;
        
        %% OK
        % compute T*A0
        TA0 = T*sys_deri(xx,par,0,[],[]);
        
       
        % add (T*A_0*sum P(c)*Delta u) to the jacobian
        for k = 0:sysm
            kk = idxjac + k*sysn;
            J(idxrange,kk:(kk+sysn-1)) = J(idxrange,kk:(kk+sysn-1)) - TA0*P(k+1);
        end;
        %%
        % iterate through the delays and add to the jacobian
        for numdelay = 1:nd

            % compute A1
            A1 = sys_deri(xx,par,numdelay,[],[]);
            if ndde
                % NDDE: compute A2
                A2 = sys_deri(xx,par,numdelay + nd,[],[]);
         
            else
                A2 = 0;
            end;
            
            % determine where in the jacobian we need to modify
            idxtau_i = (idxtau(numdelay) - 1)*sysn;
            %% OÙ EST CETTE PARTIE ? --> OK !
            % add (-T*A1*sum P(\tilde{c})*Delta u) to the jacobian
            for k = 0:sysm
                kk = idxtau_i + k*sysn + 1;   
                J(idxrange,kk:(kk+sysn-1)) = J(idxrange,kk:(kk+sysn-1)) - A1*T*Ptau(numdelay,k+1) - A2*dPtau(numdelay,k+1);
            end;
            %% OK --> concerne la période
            % add (-A1*tau*sum P'(\tilde{c})*u/T) to the jacobian
            % modifie la colonne du jacobien liée à la période
            J(idxrange,sysnml + sysn + 1) = J(idxrange,sysnml + sysn + 1) - A1*dxtau(:,numdelay)*tT(numdelay) - A2*(-dxtau(:,numdelay) + tT(numdelay)*ddxtau(:,numdelay))/T;
            
            %% OK
            % add extra derivatives in case the free parameter is the delay
            for i = 1:length(free_par)
                if (free_par(i) == n_tau(numdelay))
                    J(idxrange,sysnml + sysn + 1 + i) = J(idxrange,sysnml + sysn + 1 + i) + A1*dxtau(:,numdelay) + A2*ddxtau(:,numdelay)/T;
                end;
            end;
            
        % END: for numdelay = 1:nd
        end;
        
    % END: for m = 1:sysm
    end;

% END: for l = 1:sysl
end;

%% OK après cette ligne

% periodicity conditions
J((sysnml + 1):(sysnml + sysn),1:sysn) = eye(sysn);
J((sysnml + 1):(sysnml + sysn),(sysnml + 1):(sysnml + sysn)) = -eye(sysn);
res((sysnml + 1):(sysnml + sysn)) = profile(:,1) - profile(:,end);

% phase conditions
if phase & non_gauss,  %On n'est quasiment jamais dans ce cas là !
  for l_i=1:l
    index_a=(l_i-1)*sysm+1;
    for k=1:sysm
      fac=gauss_abs(k)*(mesh((l_i-1)*sysm+1)-mesh(l_i*sysm+1));
      dPa=poly_dla(mesh(index_a:index_a+sysm),gauss_c(k));
      Pa=poly_lgr(mesh(index_a:index_a+sysm),gauss_c(k));
      u_prime=profile(:,index_a:index_a+m)*dPa';
      for q=1:sysm+1
        J(sysnml + sysn + 1,(l_i-1)*sysnm+1+(q-1)*sysn:(l_i-1)*sysnm+q*sysn)= ...
	  J(sysnml + sysn + 1,(l_i-1)*sysnm+1+(q-1)*sysn:(l_i-1)*sysnm+q*sysn) + fac*Pa(q)*u_prime';
      end;
    end;
  end;
end;

if phase
  res(sysnml + sysn + 1,1)=0;
end;

keyboard

return;
