function [J,res,tT,extmesh]=psol_jac(funcs,c,T,psol_prof,t,deg,par,free_par,ph,varargin)
%% residual & Jacobian of collocation problem for periodic orbits
% function [J,res,tT,extmesh]=psol_jac(c,T,profile,t,deg,par,free_par,phase,varargin)
% INPUT:
%   funcs problem functions
%	c collocation parameters in [0,1]^m
%	T period
%	profile profile in R^(n x deg*l+1)
%	t representation points in [0,1]^(deg*l+1)
%	deg degree piecewise polynomial
%	par current parameter values in R^p
%	free_par free parameters numbers in N^np
%	phase use phase condition or not (s = 1 or 0)
%   wrapJ (optional key-value pair, default true) 
%        wrap time points periodically into [0,1]
% OUTPUT:
%	J jacobian in R^(n*deg*l+n+s x n*deg*l+1+n+np)
%	res residual in R^(n*deg*l+n+s)
%   tT delays, scaled by period
%   extmesh mesh of time points, extended back to -max(tT(:))

% original: (c) DDE-BIFTOOL v. 2.00, 30/11/2001
% modified by Jan Sieber to permit arbitrary nesting of state-dependent
% delays, vectorisation and optional re-use for computation of Floquet
% multipliers
%
% if wrapJ the returned jacobian is augmented with derivative wrt period and
% free_par and wrapped around periodically inside [0,1] 
% if ~wrapJ the returned jacobian puts its entries into the interval
%  [-min(delay,0),max(1-[0,delays])], no augmentation is done. This
%  Jacobian can be used for computation of Floquet multipliers and modes
%
% $Id(3.0alpha): psol_jac.m 44 2013-06-14 14:15:47Z Jan Sieber $
%
%% optional
default={'wrapJ',true};
options=dde_set_options(default,varargin,'pass_on');
%% use functions from funcs
sys_tau=funcs.sys_tau;
sys_ntau=funcs.sys_ntau;

%% define problem & problem dimensions
n=size(psol_prof,1); % get the system dimension from the dimensions of profile
np=length(free_par);
tp_del=funcs.tp_del;

if tp_del==0         % constant delay
    n_tau=sys_tau(); % delay numbers
    tau=par(n_tau);  % delay values
    tau=[0;tau(:)];  % incl tau=0
    d=length(n_tau)+1; % number of delays
    tau_dep=[];
else                 % state dependent delay WILL NOT WORK HERE 
    if isfield(funcs,'ntau_is_matrix')
        %% check if dependencies of tau(xx(:,k) are explicitly provided
        tau_dep=sys_ntau();
        d=size(tau_dep,1)+1;
        tau_dep=[zeros(1,size(tau_dep,2));tau_dep];
    else
        %% assume tau(i) depends on xx(:,1:i)
        d=sys_ntau()+1; % number of delays
        tau_dep=false(d);
        for i=1:d-1
            tau_dep(i+1,1:i)=true;
        end
    end
end

nint=(length(t)-1)/deg; % number of collocation intervals
neqs=deg*nint;          % number of equations from collocation points

%% check array sizes:
if nint~=floor(nint)
    error('PSOL_JAC: t (length%d) does not contain %d intervals of %d points!',...
        length(t),nint,deg);
end;
if length(c)~=deg && ~isempty(c)
    error('PSOL_JAC: wrong number of collocation parameters length(c)=%d, m=%d!',...
        length(c),deg);
end

%% SECTION AJOUTEE
% do some extra initialisation if we are working on an NDDE
% get the mass matrix M where M*x'(t) = f(x(t),x(t-tau),x'(t-tau))
if exist('sys_ndde')
    massmatrix = sys_ndde();
    if ((size(massmatrix,1) ~= n) || (size(massmatrix,2) ~= n))
        if (size(massmatrix,1)*size(massmatrix,2)) == 1
            massmatrix = eye(n);
        else
            error('PSOL_JAC: Incorrectly sized mass matrix given by sys_ndde');
        end;
    end;
    ndde = 1;
else
    massmatrix = eye(n);
    ndde = 0;
end;

%% obtain collocation parameters
% (create some collocation points (Gaussian) if we weren't given any)
if isempty(c)
    c=poly_gau(deg);
    gauss_c=c;
    non_gauss=0;
else
    gauss_c=poly_gau(deg);
    non_gauss=1;
end

%% phase condition initialisation:
if ph
    gauss_abs=ones(1,deg);
    g=poly_gau(deg-1);
    notk=true(1,deg);
    for k=1:deg
        notk(k)=false;
        gauss_abs(k)=gauss_abs(k)/prod(gauss_c(k)-g)/prod(gauss_c(k)-gauss_c(notk));
        notk(k)=true;
    end
    gauss_abs=gauss_abs/sum(gauss_abs);
end
%% more initialisation:
% all_Pa=NaN(deg,deg+1);
% all_dPa=NaN(deg,deg+1);
all_Pa = NaN(deg+1,deg+1);
all_dPa=NaN(deg+1,deg+1);
all_ddPa=NaN(deg+1,deg+1);

for m_i=1:deg
    P0(m_i,:) = poly_elg(sysm,c(m_i));
    dP0(m_i,:) = poly_del(sysm,c(m_i));
    ddP0(m_i,:) = poly_ddel(sysm,c(m_i));
%     all_dPa(m_i,:)=poly_dla((0:deg)/deg,c(m_i));
%     all_Pa(m_i,:)=poly_lgr((0:deg)/deg,c(m_i));
end
%% pre-allocate needed temporary arrays
Pb=zeros(d,deg+1,neqs);  % Lagrange stamp, mapping delayed values onto profile
dPb=zeros(d,deg+1,neqs); % Lagrange stamp, mapping delayed derivatives onto profile
%ajout NDDE
ddPb = zeros(d,deg+1,neqs);
%
xx=zeros(n,d,neqs);  % array [x(t),x(t-tau1),...]
dtx=zeros(n,d,neqs);  % array [x'(t),x'(t-tau1),...]
c_tau=zeros(d,neqs); % time points t-tau(i-1) for current colloc point t
c_tau_mod=zeros(d,neqs); % time points t-tau(i-1) for current colloc point t (mod[0,1])
index_b=zeros(d,neqs); % starting indices of collocation intervals for t-tau(i-1)
index_b_mod=zeros(d,neqs); % starting indices of collocation intervals for t-tau(i-1) (mod[0,1])
hhh=zeros(d,neqs); % length of collocation interval in which t-tau(i-1) lies
c_tau_trans=zeros(d,neqs); % position of t-tau(i) in colloc interval, rescaled to [0,1]

if tp_del~=0
    tT=NaN(d,neqs);
    tT(1,:)=0;
else
    tT=tau(:)/T;
    tT=repmat(tT,1,neqs);
end
%% for all collocation points, generate equation 
% (vectorization in l_i & m_i possible)
for l_i=1:nint
    %% determine index for a in profile:
    i0=(l_i-1)*deg;
    t_start=t(i0+1);
    %% iterate over collocation points
    for m_i=1:deg
        i=i0+m_i;
        index_b(1,i)=i0+1;
        index_b_mod(1,i)=index_b(1,i);
        hhh(1,i)=t(i0+1+deg)-t_start;
        % determine c
        c_tau(1,i)=t_start+c(m_i)*hhh(1,i);
        % determine dPa for a:
        dPb(1,:,i)=all_dPa(m_i,:)/hhh(1,i);
        % add sum a*dPa to res:
        dtx(:,1,i)=psol_prof(:,index_b(1,i)+(0:deg))*dPb(1,:,i)';
        %  determine Pa for a:
        Pb(1,:,i)=all_Pa(m_i,:);
        % AJOUT NDDE
        ddPb = all_ddPa(m_i,:)/(h^2);
       
        %% compute x:
        xx(:,1,i)=psol_prof(:,index_b(1,i)+(0:deg))*Pb(1,:,i)';
        
        
        
        %% compute tau, c_tau, xx, dtx
        
        %UTILE UNIQUEMENT SI ON A UN SYSTEME A PLUSIEURS RETARDS
        for t_i=2:d
            if tp_del~=0
                tT(t_i,i)=sys_tau(t_i-1,xx(:,1:t_i,i),par)/T;
            end
            c_tau(t_i,i)=c_tau(1,i)-tT(t_i,i);
            c_tau_mod(t_i,i)=mod(c_tau(t_i,i),1);
            % determine index for b in profile:
            index_b_colloc=find(t(1:deg:end)<c_tau_mod(t_i,i),1,'last');
            index_b_mod(t_i,i)=(index_b_colloc-1)*deg+1;
            index_b(t_i,i)=index_b_mod(t_i,i)+round(c_tau(t_i,i)-c_tau_mod(t_i,i))*nint*deg;
            % c transformed to [0,1] and hhh_tau
            hhh(t_i,i)=t(index_b_mod(t_i,i)+deg)-t(index_b_mod(t_i,i));
            c_tau_trans(t_i,i)=(c_tau_mod(t_i,i)-t(index_b_mod(t_i,i)))/hhh(t_i,i);
            % determine Pb for b:
            Pb(t_i,:,i)=poly_elg(deg,c_tau_trans(t_i,i));
            % compute x_tau:
            xx(:,t_i,i)=psol_prof(:,index_b_mod(t_i,i):index_b_mod(t_i,i)+deg)*Pb(t_i,:,i)';
            dPb(t_i,:,i)=poly_del(deg,c_tau_trans(t_i,i))/hhh(t_i,i);
            % AJOUT NDDE:
            ddPb(t_i,:,i) = poly_ddel(deg,c_tau_trans(t_i,i))/(hhh(t_i,i)^2);
            ddtx(:,t_i,i) = psol_prof(:,index_b_mod(t_i,i):index_b_mod(t_i,i)+deg)*ddPb(t_i,:,i)';
            %
            dtx(:,t_i,i)=psol_prof(:,index_b_mod(t_i,i):index_b_mod(t_i,i)+deg)*dPb(t_i,:,i)';
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
%% determine index ranges for wrapped or unwrapped Jacobian
if ~options.wrapJ % compute Jde_dx only for Floquet multipliers
    indmin=min(index_b(:));
    indshift=1-indmin;
    indmax=max(index_b(:))+deg;
    doJcomb=false;
    % set up extended mesh
    indrg=indmin:indmax;
    t_ind=mod(indrg-1,nint*deg)+1;
    t_shift=floor((indrg-1)/(nint*deg));
    extmesh=t(t_ind)+t_shift;
    index_b=index_b+indshift;
else % compute augmented jacobian
    indshift=0;
    indmax=deg*nint+1;
    index_b=index_b_mod;
    doJcomb=true;
    extmesh=t;
end
%% init J, res:
resde=zeros(n,deg*nint);
Jde_dx=zeros(n,deg*nint,n,indshift+indmax);
if doJcomb %si on calcule un jacobien augmenté ?
    Jde_dT=zeros(n,deg*nint);
    Jde_dp=zeros(n,deg*nint,np);
    Jbc_dx=zeros(n,n,deg*nint+1);
    Jbc_dp=zeros(n,np);
    Jbc_dT=zeros(n,1);
end
if ph
    resph=0;
    Jph_dx=zeros(n,deg*nint+1);
else
    resph=[];
    Jph_dx=zeros(0,n*(deg*nint+1));
end
%% obtain all values of sys_rhs, sys_deriv and sys_dxtau
vals=psol_sysvals(funcs,xx,par,free_par,tp_del,tau_dep);
%%
for l_i=1:nint
    i0=(l_i-1)*deg;
    for m_i=1:deg
        i=i0+m_i;
        %% precompute all Jacobians for delayed values after delayed values are known
        if tp_del~=0 %%PARTIE POUR SD-DDE
            dxxdx=zeros([n,n,d,d]); %% dxx(:,k)/dx (sdddes)
            dxxdp=zeros([n,np,d]); %% dxx(:,k)/dp (sdddes)
            dxxdT=zeros([n,d]); %% dxx(:,k)/dT (sdddes)
            dxxdx(:,:,1,1)=eye(n);
            for t_i=2:d %pour plusieurs retards
                sel=find(tau_dep(t_i,:));
                dxxdx(:,:,t_i,t_i)=eye(n);
                prefac=dtx(:,t_i,i)/T;
                dxxdp(:,:,t_i)=-prefac*vals.dtau_dp(t_i,:,i);
                dxxdT(:,t_i)=prefac*tT(t_i,i);
                for t_k=sel
                    fac=prefac*vals.dtau_dx(:,t_k,t_i,i)';
                    dxxdxk=reshape(fac*reshape(dxxdx(:,:,:,t_k),[n,n*d]),[n,n,d]);
                    dxxdx(:,:,:,t_i)=dxxdx(:,:,:,t_i)-dxxdxk;
                    dxxdp(:,:,t_i)=dxxdp(:,:,t_i)-fac*dxxdp(:,:,t_k);
                    dxxdT(:,t_i)=dxxdT(:,t_i)-fac*dxxdT(:,t_k);
                end
            end
        end
        %% insert all derivatives into large Jacobians
        %% add dtx for x' in Jx and res:
        resde(:,i)=dtx(:,1,i);
        Jde_dx(:,i,:,index_b(1,i)+(0:deg))=Jde_dx(:,i,:,index_b(1,i)+(0:deg))...
            +reshape(kron(dPb(1,:,i),eye(n)),[n,1,n,deg+1]);
        if doJcomb
            %% add parameter in Jde_dp:
            for p_i=1:np
                Jde_dp(:,i,p_i)=Jde_dp(:,i,p_i)-T*vals.dfdp(:,p_i,i);
            end
            %% phase_condition:
            if ph && ~non_gauss
                fup=gauss_abs(m_i)*hhh(1,i)*dtx(:,1,i);
                Jph_dx(:,index_b(1,i)+(0:deg))=Jph_dx(:,index_b(1,i)+(0:deg))+...
                    kron(Pb(1,:,i),fup);
            end
            %% add -f for dT in J:
            Jde_dT(:,i)=Jde_dT(:,i)-vals.f(:,i);
        end
        %% add Tf in res:
        resde(:,i)=resde(:,i)-T*vals.f(:,i);
        %% delayed values (incl tau=0): insert Jacobians into J
        for t_i=1:d
            if tp_del==0
                %% add -T*Pb*dfdx(:,t_i)
                Jde_dx(:,i,:,index_b(t_i,i)+(0:deg))=...
                    Jde_dx(:,i,:,index_b(t_i,i)+(0:deg))-...
                    reshape(kron(Pb(t_i,:,i),T*vals.dfdx(:,:,t_i,i)),[n,1,n,deg+1]);
                if doJcomb
                    %% add -T*A1*sum b*dP*dc_tau for dT in J:
                    Jde_dT(:,i)=Jde_dT(:,i)-vals.dfdx(:,:,t_i,i)*dtx(:,t_i,i)*tT(t_i,i);
                end
            else
                for t_k=1:t_i
                    dfdxxik=T*vals.dfdx(:,:,t_i,i)*dxxdx(:,:,t_k,t_i);
                    Jde_dx(:,i,:,index_b(t_k,i)+(0:deg))=...
                        Jde_dx(:,i,:,index_b(t_k,i)+(0:deg))-...
                        reshape(kron(Pb(t_k,:,i),dfdxxik),[n,1,n,deg+1]);
                end
                if doJcomb
                    Jde_dp(:,i,:)=Jde_dp(:,i,:)-reshape(T*vals.dfdx(:,:,t_i,i)*dxxdp(:,:,t_i),[n,1,np]);
                    Jde_dT(:,i)=Jde_dT(:,i)-T*vals.dfdx(:,:,t_i,i)*dxxdT(:,t_i);
                end
            end
            %% parameter derivative if delay is free par and ~sd-dde
            if tp_del==0 && doJcomb && t_i>1
                p_i=find(free_par==n_tau(t_i-1),1,'first');
                if ~isempty(p_i)
                    Jde_dp(:,i,p_i)=Jde_dp(:,i,p_i)+vals.dfdx(:,:,t_i,i)*dtx(:,t_i,i);
                end
            end
        end
    end
end
Jde_dx=reshape(Jde_dx,[n*deg*nint,n*(indshift+indmax)]);
if ~doJcomb
    res=resde(:);
    J=Jde_dx;
    return
end
%% periodicity condition:
Jbc_dx(:,:,1)=eye(n);
Jbc_dx(:,:,end)=-eye(n);
resbc=psol_prof(:,1)-psol_prof(:,size(psol_prof,2));

%% phase condition:
if ph && non_gauss
    point=struct('kind','psol','parameter',par,'mesh',t,'degree',deg,...
        'profile',psol_prof,'period',T);
    p0=p_axpy(0,point,[]);
    [resph,p_Jph_dx]=p_dot(p0,point);
    Jph_dx=p_Jph_dx.profile(:)';
end
%% assemble overall residual & Jacobian
res=[resde(:);resbc(:);resph];
J=[Jde_dx,Jde_dT(:),reshape(Jde_dp,[n*deg*nint,np]);...
    reshape(Jbc_dx,[n,n*(deg*nint+1)]),Jbc_dT,Jbc_dp];
if ph
    J=[J; Jph_dx(:)',0,zeros(1,np)];
end
end
