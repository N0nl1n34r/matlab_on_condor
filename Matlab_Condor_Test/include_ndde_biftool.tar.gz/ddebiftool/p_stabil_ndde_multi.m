function [stab,eigv] = p_stabil_ndde_multi(funcs,st1,N)
% function [stab,eigv] = p_stabil_ndde_multi(st1,N)
%
% Use the method described in Breda, Maset, and Vermiglio 2006
% (Pseudospectral approximation of eigenvalues of derivative operators with
% non-local boundary conditions)
%
% st1 is a steady state solution
% N is the (optional) size of the discretisation to use
%
% Uses a modified version of A Matlab Differentiation Matrix Suite by JAC
% Weideman and SC Reddy
% <http://dip.sun.ac.za/~weideman/research/differ.html>

sys_tau = funcs.sys_tau;
sys_deri = funcs.sys_deri;

if exist('N', 'var') ~= 1
    N = 100;
end;

% dimension of system
n = size(st1.x,1);

% get the delays and the maximum delay
tau = st1.parameter(sys_tau());
nTau = length(tau);
maxTau = max(tau);

% get the differentiation matrix and the Chebyshev nodes
[~, D] = chebdif(N, 1);

% chebdif returns the Chebyshev differentiation matrix on [1..-1] so
% rescale to [-1..0]
D = -D*2/maxTau;

% Fudge it to the correct dimension
D = kron(D, eye(n));
A = D;

% Construct the solution vector (remember, neutral derivatives are zero at
% an equilibrium)
xx = st1.x*[1 ones(1, nTau) zeros(1, nTau)];

% Overwrite the bottom row of the matrix A
A(end-n+1:end, :) = 0;

% Add the necessary derivatives
L0 = sys_deri(xx,st1.parameter,0,[],[]);
A(end-n+1:end,end-n+1:end) = L0;

% Add the delayed derivatives
for i = 1:nTau
    Li = sys_deri(xx,st1.parameter,i,[],[]); % Get the delay derivatives
    Ni = sys_deri(xx,st1.parameter,i+nTau,[],[]); % Get the neutral derivatives
    [~, I] = chebintD(zeros(1, N), -2*tau(i)/maxTau + 1); % Rescale tau to the interval [-1..1]
    I = I(end:-1:1,:); % Put the columns in the right order
    I = kron(I, eye(n)); % Expand to the system dimension
    A(end-n+1:end, :) = A(end-n+1:end, :) + Li*I + Ni*I*D;  
    % h*w(j)*M(z)*I(z)
    % MLi(z)*h*w*I
    % MNi(z)*h*w*I*D
end

%{
   JacM = sys_deri(xx, st1.parameter, 2*nTau+1, [], []);
   JacN = sys_deri(xx, st1.parameter, 2*nTau+2, [], []); 
   [zz, w] = clencurt(N);
   h = (tau_min - tau_max)/2;
   H = (tau_min + tau_max)/2;
   for j = 1:(N+1) % approximate integral with clenshaw curtis quadrature
      a_tau = h*zz(j)+H

      [~, I] = chebintD(zeros(1, N), -2*a_tau/maxTau + 1); % Rescale tau to the interval [-1..1]
      I = I(end:-1:1,:); % Put the columns in the right order
      I = kron(I, eye(n)); % Expand to the system dimension

      summand = h*w(j)*(JacM*M(a_tau)*I + JacN*N(a_tau)*I*D);
      A(end-n+1:end, :) = A(end-n+1:end, :) + summand;
   end

% clencurt from traceDDE package
function [xx,w]=clencurt(N)
	theta=pi*(0:N)'/N;
	xx=cos(theta);
	w=zeros(1,N+1);
	ii=2:N;
	v=ones(N-1,1);
	if mod(N,2)==0
	    w(1)=1/(N^2-1);
	    w(N+1)=w(1);
	    for k=1:N/2-1
		v=v-2*cos(2*k*theta(ii))/(4*k^2-1);
	    end
	    v=v-cos(N*theta(ii))/(N^2-1);
	else
	    w(1)=1/N^2;
	    w(N+1)=w(1);
	    for k=1:(N-1)/2
		v=v-2*cos(2*k*theta(ii))/(4*k^2-1);
	    end
	end
	w(ii)=2*v/N;
end;
%}

MassMatrixN = eye(n*(N+1));
MassMatrix = sys_ndde();
if(~isscalar(MassMatrix))
	display("Using Mass Matrix to Calculate EVs");
	%MN = repmat({sys_ndde()}, 1, N+1);
	MassMatrixN = blkdiag(eye(N*n), MassMatrix);
        %MassMatrixN = repmat(sys_ndde(), N+1)
end

% Calculate the eigenvalues
if nargout == 2
    [eigv,l] = eig(A, MassMatrixN);
    l = diag(l);
    [~,idx] = sort(real(l),1,'descend');
    eigv = eigv(:,idx);
else
    l = eig(A, MassMatrixN);
    [~,idx] = sort(real(l),1,'descend');
end;

stab.l0 = [];
stab.l1 = l(idx);
stab.n1 = [];
stab.l1 = stab.l1(~isinf(stab.l1));
