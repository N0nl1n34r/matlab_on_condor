function [mu,eigenfuncs]=mult_app(funcs,period,profile,mesh,degree,rho,max_number,col,par,d_ac)
%% find Floquet multipliers & modes of periodic orbit
% function [mu,eigenfuncs]=mult_app(period,profile,mesh,degree,rho,max_number,col,par,d_ac)
% INPUT: 
%   funcs problem functions
%	period period of solution
%	profile periodic solution profile
%       mesh periodic solution mesh (if empty, mesh is assumed uniform)
%	degree degree of piecewise polynomials
%       rho keep multipliers with modulus >= rho
%	max_number keep at most max_number multipliers 
%	col collocation points
%       par current parameter values in R^p
%       d_ac (only for state-dependent delays) tau<d_ac is treated as 
%             tau<0 (stability is not computed)
% OUTPUT:
%       mu approximations of requested multipliers
%       eigenfuncs (if requested) corresponding modes

% original (c) DDE-BIFTOOL v. 2.00, 30/11/2001
% modified by Jan Sieber to avoid code repetition
%
% $Id(3.0alpha): mult_app.m 35 2013-06-13 11:41:21Z Jan Sieber $
%
%%
if nargin<10
    d_ac=1e-8;
end
%% if mesh is empty assume equidistant mesh:
if isempty(mesh)
  mesh=0:1/(size(profile,2)-1):1;
end;
%% obtain Jacobian
[J,resdum,tT,extmesh]=psol_jac(funcs,col,period,profile,mesh,degree,par,...
    [],false,'wrapJ',false); %#ok<ASGLU>
m=degree;
n=size(profile,1);
delays=tT(2:end,:);
if nargout>1 || (numel(delays)>0 && min(delays(:))<d_ac)
    % solve full eigenvalue problem
    solvefull=true;
    if nargout>1
        geteigenfuncs=true;
    else
        geteigenfuncs=false;
    end
else
    geteigenfuncs=false;
    solvefull=false;
end
if ~solvefull
    %% DDE or ODE compute monodromy matrix
    M=monodromy_matrix(J,n,m,extmesh);
    if isempty(M)
        mu=[];
        return;
    end;
    s=eig(M);
else
    %% negative delays present or eigenvectors required
    ll=length(extmesh);
    n_ext=sum(extmesh<=0|extmesh>1)*n;
    B=zeros(ll*n);
    B(end-n_ext+1:end,1:n_ext)=eye(n_ext);
    J=[J;...
        zeros(n_ext,ll*n-n_ext),eye(n_ext)];
    if ~geteigenfuncs
        s=eig(J,B);
    else
        [ef,s]=eig(J,B);
        s=diag(s);
    end
    sel=~isinf(s) & ~isnan(s);
    s=s(sel);
    if geteigenfuncs
        ef=ef(:,sel);
    end
end
[dummy,I]=sort(abs(s)); %#ok<ASGLU>

mu=s(I(end:-1:1));
mu=mu(1:min(max_number,length(mu)));
sel=abs(mu)>=rho;
mu=mu(sel);
if geteigenfuncs
    ef=ef(:,I(end:-1:1));
    ef=ef(:,1:min(max_number,length(mu)));
    eigenfuncs=ef(:,sel);
end
end
