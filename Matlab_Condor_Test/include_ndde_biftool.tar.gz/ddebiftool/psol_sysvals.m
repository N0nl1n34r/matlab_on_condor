function sysvals=psol_sysvals(funcs,xx,par,free_par,tp_del,tau_dep,dtx)
%% call right-hand sides and derivatives and derivatives of delays in all points listed in xx
% extracted by Jan Sieber from DDE-Biftool's psol_jac to enable vectorisation
% modified on 7/11/2013 by Soizic Terrien to support neutral systems
% $Id(3.0alpha): psol_sysvals.m 35 2013-06-13 11:41:21Z Jan Sieber $
%
% disp('en entree sysvals')


%% use functions from funcs
sys_rhs=funcs.sys_rhs;
sys_deri=funcs.sys_deri;
sys_dtau=funcs.sys_dtau;

if exist('sys_ndde')
    ndde=1;
else
    ndde=0;
end
%% problem dimensions
n=size(xx,1);
% if ndde
%     d=size(xx,2)-0.5*(size(xx,2)-1); 
% else
d=size(xx,2);
% end
nvec=size(xx,3);
%keyboard
%% pre-allocate needed temporary arrays
f=zeros(n,nvec);
dfdx=zeros(n,n,d,nvec);  %df/d[xx[k]] for k=1..d+1
dfddx=zeros(n,n,d,nvec);
dfdp=zeros(n,length(free_par),nvec);  %df/dp for k=1..d+1
if tp_del~=0
    dtau_dx=zeros(n,d-1,d,nvec); % dtau(i)/d[xx(k)]  for k=2..d+1
    dtau_dp=zeros(d,length(free_par),nvec); % dtau(i)/d[par(k)]
else
    dtau_dx=[];
    dtau_dp=[];
end
%% check if vectorization has to be replaced by for loop
if nvec>1 && (~isfield(funcs,'x_vectorized')||~funcs.x_vectorized)
    slices=num2cell(1:nvec);
else
    slices={1:nvec};
end
for i=1:length(slices)
    ind=slices{i};
    %% compute f(x,x_tau):
    
%     keyboard
    f(:,ind)=sys_rhs([xx(:,:,ind) dtx(:,:,ind)],par);
    
    %% determine df/dp:
    for p_i=1:length(free_par)
        dfdp(:,p_i,ind)=sys_deri([xx(:,:,ind) dtx(:,:,ind)],par,[],free_par(p_i),[]);
    end
    %% precompute all Jacobians for delayed values after delayed values are known
    
    for t_i=1:d
        dfdx(:,:,t_i,ind)=sys_deri([xx(:,:,ind) dtx(:,:,ind)],par,t_i-1,[],[]);
        if tp_del~=0 && t_i>1
            sel=find(tau_dep(t_i,:));
            for t_k=sel
                dtau_dx(:,t_k,t_i,ind)=sys_dtau(t_i-1,xx(:,:,ind),par,t_k-1,[]);
            end
            for p_i=1:length(free_par)
                dtau_dp(t_i,p_i,ind)=sys_dtau(t_i-1,xx(:,:,ind),par,[],free_par(p_i));
            end
        end
    end
    
    
    %% AJOUT POUR NDDE
    if ndde
%            dfddx(:,:,1,ind) =  zeros(n,n,1,nvec);
        for t_i=2:d % for each delay, skipping the 0 delay 
            dfddx(:,:,t_i,ind)=sys_deri([xx(:,:,ind) dtx(:,:,ind)],par,t_i-1+d-1,[],[]); % d-1 parce que d prend en compte le retard nul !et que l'indexage commence a 0 dans sys_deri
        end
    else
        dfddx=[];
    end    
end

% keyboard

sysvals=struct('f',f,'dfdx',dfdx,'dfdp',dfdp,'dtau_dp',dtau_dp,'dtau_dx',dtau_dx,'dfddx',dfddx);

end
