N = 5; % Number of Chebyshev nodes
[nodes, D] = chebdif(N, 1); % Get the Chebyshev nodes and (1st) differentiation matrix

testdata = sin(pi*nodes); % Generate a known function as some test data
Dtestdata = D*testdata; % Derivative of the test data using Chebyshev polynomials

figure; plot(nodes, Dtestdata); title('Derivative of sin(pi x) using Chebyshev polynomials');

xx = rand(); % Pick a random point on [0,1] to interpolate

[~, I] = chebintD(zeros(size(testdata)), xx); % Calculate the interpolation matrix (the first argument is not really needed since we only want the interpolation matrix and not the interpolated value directly)

testdataxx = I*testdata;

fprintf('sin(pi*%g) = %g (by interpolation); error is %g\n', [xx, testdataxx, abs(sin(pi*xx)-testdataxx)]);
fprintf('d/dx[sin(pi*x)]|_(x=%g) = %g (by interpolation); error is %g\n', [xx, I*D*testdata, abs(pi*cos(pi*xx)-I*D*testdata)]);


