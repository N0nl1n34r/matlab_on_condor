function M=monodromy_matrix(J,n,deg,tt)
%% create monodromy matrix from collocation Jacobian
% function M=monodromy_matrix(J,n,mm,tt)
% INPUT:
%   J extended jacobian matrix of collocation system
%	n dimension of the problem
%	deg degree of collocation polynomial
%	tt extended mesh in [-tmin,1] (tmin is the start of the collocation
% OUTPUT: 
%	M approximation of monodromy matrix

% original code (c) DDE-BIFTOOL v. 2.00, 30/11/2001
%% extracted by Jan Sieber to avoid code repetition
%
% $Id(3.0alpha): monodromy_matrix.m 35 2013-06-13 11:41:21Z Jan Sieber $
%
mmn=deg*n;
k=find(tt>=0,1,'first');
kn=k*n;

for i=1:(size(J,2)-kn)/mmn
  X=J(mmn*(i-1)+1:mmn*i,kn+1+mmn*(i-1):kn+mmn*i);
  [L,U,P]=lu(X); %#ok<ASGLU>
  J(mmn*(i-1)+1:mmn*i,:)=L\P*J(mmn*(i-1)+1:mmn*i,:);
  for j=2:mmn
    for q=1:j-1
      J(mmn*(i-1)+j,kn+q+mmn*(i-1))=0;
    end;
  end;
end;

lJ1=size(J,1);
lJ2=size(J,2);

for i=1:(lJ2-kn)/mmn,
  mmn_i_1=mmn*(i-1);
  kn_mmn_i_1=kn+mmn*(i-1);
  for j=1:mmn
    kn_mmn_i_1_j=kn_mmn_i_1+j;
    pivot=J(mmn_i_1+j,:)/J(mmn_i_1+j,kn_mmn_i_1_j);
    qq=mmn_i_1+j+1:lJ1;
    ql=qq(J(qq,kn_mmn_i_1_j)~=0);
    for l=1:length(ql)
      q=ql(l);
      J(q,:)=J(q,:)-J(q,kn_mmn_i_1_j)*pivot;
      J(q,kn_mmn_i_1_j)=0;
    end
  end
end

% extract M:

if kn<size(J,2)-kn+1
  M0=J(lJ1-kn+1:lJ1,lJ2-kn+1:lJ2);
  M1=J(lJ1-kn+1:lJ1,1:kn);
  M=-M0\M1;
else
  overlap=kn-(lJ2-kn+1)+1;
  M0=J(lJ1-kn+1+overlap:lJ1,lJ2-kn+1+overlap:lJ2);
  M1=J(lJ1-kn+1+overlap:lJ1,1:kn);
  M(1:overlap,kn-overlap+1:kn)=eye(overlap);
  M(overlap+1:kn,1:kn)=-M0\M1;
end
end