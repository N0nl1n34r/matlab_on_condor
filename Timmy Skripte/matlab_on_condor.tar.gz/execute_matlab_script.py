#!/usr/bin/python
# not testet (yet)!
import numpy as np
import subprocess
import sys



#parse the command line arguments
arg = sys.argv[1:]
for i in np.arange(len(arg)):
        if (arg[i] == '-i'):
            scriptname = arg[i+1]
            directoryname = arg[i+2]

#extract all copied tarballs            
subprocess.call("""find -maxdepth 1 -name "*tar.gz" -exec tar xzf '{}' \;""", shell= True)

#start matlab without graphical user interface, add all folders and subfolders in current folder to path, run scriptname and then exit matlab so that this python script can continue and so that condor realizes at the end of this script
#that the job is done
string_cmd = """matlab -nosplash -nodesktop -noFigureWindows -r "addpath(genpath('.')); run('{0}');exit;" """.format(scriptname)
print string_cmd

#execute above command
subprocess.call(string_cmd, shell = True)
#compress the directory containing the solution files into a tarball/.tar.gz in order to allow condor to transfer it back to host machine

# every file in folder is compressed into a tarball wich is named directoryname.tar.gz
subprocess.call("tar -zcf {0:}.tar.gz *".format(directoryname), shell = True)


#extract with tar xvf temp.gar.gz
